from django.shortcuts import render
from django.views.generic import ListView, DetailView, DeleteView, CreateView, UpdateView
from .models import Post, Category, Comments, Likes


class GetPosts(ListView):
    model = Post
    template_name = 'app/index.html'
    context_object_name = 'posts'


class GetDetail(DetailView):
    model = Post
    template_name = 'app/post_list.html'
    context_jbject_name = 'posts'



class CreatePost(CreateView):
    model = Post
    fields = '__all__'
    success_url = '/proj'
    template_name = 'app/post_form.html'


class UpdatePost(UpdateView):
    model = Post
    fields = '__all__'
    success_url = '/proj'
    template_name = 'app/post_form.html'


class DeletePost(DeleteView):
    model = Post
    success_url = '/proj'


# class